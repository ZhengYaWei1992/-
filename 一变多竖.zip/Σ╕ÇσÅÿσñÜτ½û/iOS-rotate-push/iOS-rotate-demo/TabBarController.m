//
//  TabBarController.m
//  iOS-rotate-demo
//
//  Created by Dvel on 16/4/20.
//  Copyright © 2016年 Dvel. All rights reserved.
//

#import "TabBarController.h"
#import "A_Controller.h"
#import "A_A_ViewController.h"

@interface TabBarController ()

@end

@implementation TabBarController
- (void)viewDidLoad{
    [super viewDidLoad];
}

-(BOOL)shouldAutorotate{
    UINavigationController *navC = self.selectedViewController;
    UIViewController *currentVC = navC.visibleViewController;
    return [currentVC shouldAutorotate];
}
//支持的方向
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    UINavigationController *navC = self.selectedViewController;
    UIViewController *currentVC = navC.visibleViewController;
    return [currentVC supportedInterfaceOrientations];;
}

@end
